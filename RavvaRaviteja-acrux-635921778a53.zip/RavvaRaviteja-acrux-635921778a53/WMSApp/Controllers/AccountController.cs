﻿using System;
using System.Globalization;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using WMS.Common.BussinessLogic;
using WMS.Common.DataModel;
using WMSApp.Models;

namespace WMSApp.Controllers
{

    public class AccountController : Controller
    {
        static readonly IWMSInterface _wmsprovider;
        static AccountController()
        {
            _wmsprovider = null; // new WMSProvider();

        }
        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(LoginViewModel loginModel)
        {
            if (ModelState.IsValid)
            {
                EmployeeModel empModel = _wmsprovider.GetUserDetails(loginModel.Login.Username, loginModel.Login.Password);
                if (empModel != null && !string.IsNullOrEmpty(empModel.EMPID))
                {
                    if (loginModel.Login.RemberMe == true)
                    {
                        Response.Cookies["UserName"].Expires = DateTime.Now.AddDays(30);
                        Response.Cookies["Password"].Expires = DateTime.Now.AddDays(30);
                    }
                    else
                    {
                        Response.Cookies["UserName"].Expires = DateTime.Now.AddDays(-1);
                        Response.Cookies["Password"].Expires = DateTime.Now.AddDays(-1);
                    }
                    Response.Cookies["UserName"].Value = loginModel.Login.Username.Trim();
                    Response.Cookies["Password"].Value = loginModel.Login.Password.Trim();
                    Session["CurrentUser"] = empModel.EMPNAME;
                    Session["EmployeeId"] = empModel.EMPID;
                    return RedirectToAction("EmployeeDashBoard", "DashBoard");
                }
                else
                {
                    ModelState.AddModelError("", "Username or Password is invalid");
                    return View(loginModel);
                }

            }
            return View(loginModel);
        }

        public ActionResult LogOff(string id)
        {
            Session.Clear();
            Session.Abandon();
            Session.RemoveAll();
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1));
            Response.Cache.SetNoStore();
            //FormsAuthentication.SignOut(); //you write this when you use FormsAuthentication

            return RedirectToAction("Login", "Account");
        }

    }
}