﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WMSApp.Models;
using WMS.Common.BussinessLogic;

namespace WMSApp.Controllers
{

    public class DashBoardController : Controller
    {
        static readonly IWMSInterface _wmsprovider;
        static DashBoardController()
        {
            _wmsprovider = null; // new WMSProvider();

        }
        List<string> errors = new List<string>();

        // GET: DashBoard
        public ActionResult EmployeeDashBoard()
        {
            return View();
        }
        public ActionResult EmployeeDetails()
        {
            DashBoardViewModel viewModel = new DashBoardViewModel();
            string employeeId;
            if(Session["EmployeeId"] != null)
            {
                employeeId = Session["EmployeeId"] as string;
            }
            else
            {
                return RedirectToAction("LogOff", "Account");
            }
            try
            {
                viewModel.EmployeeModel = _wmsprovider.GetEmployeeDetailsByEmpId(employeeId);

            }
            catch (Exception ex)
            {

                throw ex;
            }
            return PartialView("~/Views/DashBoard/_EmployeeDashBoardPartial.cshtml", viewModel);
        }

        public ActionResult EmployeeSuggestions()
        {
            EmployeeSuggestionsViewModel viewModel = new EmployeeSuggestionsViewModel();
            string employeeId;
            if (Session["EmployeeId"] != null)
            {
                employeeId = Session["EmployeeId"] as string;
            }
            else
            {
                return RedirectToAction("LogOff", "Account");
            }
            try
            {
                viewModel.EmployeeSuggestions = _wmsprovider.EmployeeSuggestions(employeeId);

            }
            catch (Exception ex)
            {

                throw ex;
            }
            return PartialView("~/Views/DashBoard/_EmployeeSuggestionsPartial.cshtml", viewModel);
        }

        public ActionResult SaveEmployeeSuggestions(EmployeeSuggestionsViewModel suggestionsViewModel)
        {
            string employeeId;
            if (Session["EmployeeId"] != null)
            {
                employeeId = Session["EmployeeId"] as string;
            }
            else
            {
                return RedirectToAction("LogOff", "Account");
            }
            try
            {
                if (ModelState.IsValid)
                {
                    suggestionsViewModel.EmployeeSuggestions.EmployeeId = employeeId;
                    suggestionsViewModel.EmployeeSuggestions.EmployeeName = Session["CurrentUser"] as string;
                    _wmsprovider.SaveEmployeeSuggestions(suggestionsViewModel.EmployeeSuggestions);
                }
                else
                {
                    errors.AddRange(ModelState.Values.SelectMany(a => a.Errors).Select(a => a.ErrorMessage).ToList());
                }

            }
            catch (Exception ex)
            {
                errors.Add(ex.Message);
               
            }
            return Json(errors,JsonRequestBehavior.AllowGet);
        }

        public ActionResult EmployeeLeaveBalance()
        {
            EmployeeLeaveBalanceViewModel viewModel = new EmployeeLeaveBalanceViewModel();
            string employeeId;
            if (Session["EmployeeId"] != null)
            {
                employeeId = Session["EmployeeId"] as string;
            }
            else
            {
                return RedirectToAction("LogOff", "Account");
            }
            try
            {
                viewModel.EmployeeLeaveBal = _wmsprovider.GetLeaveBalance(Convert.ToInt32(employeeId));

            }
            catch (Exception ex)
            {

                throw ex;
            }
            return PartialView("~/Views/DashBoard/_EmployeeLeaveBalancePartial.cshtml", viewModel);
        }

        public ActionResult EmployeeAttendance()
        {
            EmployeeLeaveBalanceViewModel viewModel = new EmployeeLeaveBalanceViewModel();
            string employeeId;
            if (Session["EmployeeId"] != null)
            {
                employeeId = Session["EmployeeId"] as string;
            }
            else
            {
                return RedirectToAction("LogOff", "Account");
            }
            try
            {
              //  viewModel.EmployeeLeaveBal = _wmsprovider.GetLeaveBalance(Convert.ToInt32(employeeId));

            }
            catch (Exception ex)
            {

                throw ex;
            }
            return PartialView("~/Views/DashBoard/_EmployeeAttendancePartial.cshtml");
        }


        public ActionResult SaveEmployeeLeavesReq(EmployeeLeaveBalanceViewModel leaveViewModel)
        {
            string employeeId;
            if (Session["EmployeeId"] != null)
            {
                employeeId = Session["EmployeeId"] as string;
            }
            else
            {
                return RedirectToAction("LogOff", "Account");
            }
            try
            {
                if (ModelState.IsValid)
                {
                    leaveViewModel.EmployeeLeaveBal.EmployeeId = Convert.ToInt32(employeeId);
                    _wmsprovider.SaveEmployeeLeaveBal(leaveViewModel.EmployeeLeaveBal);
                }
                else
                {
                    errors.AddRange(ModelState.Values.SelectMany(a => a.Errors).Select(a => a.ErrorMessage).ToList());
                }

            }
            catch (Exception ex)
            {
                errors.Add(ex.Message);

            }
            return Json(errors, JsonRequestBehavior.AllowGet);
        }
    }
}