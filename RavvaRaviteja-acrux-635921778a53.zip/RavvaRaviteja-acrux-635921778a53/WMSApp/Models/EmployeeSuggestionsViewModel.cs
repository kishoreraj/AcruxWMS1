﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WMS.Common.DataModel;

namespace WMSApp.Models
{
    public class EmployeeSuggestionsViewModel
    {
        public EmployeeSuggestionsModel EmployeeSuggestions { get; set; }
    }
}