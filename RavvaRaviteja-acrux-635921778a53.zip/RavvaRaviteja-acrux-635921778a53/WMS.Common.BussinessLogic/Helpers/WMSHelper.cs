﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WMS.Common.DataModel;
using WMS.Common.EntityFramework;

namespace WMS.Common.BussinessLogic
{
    public static class WMSHelper
    {
        //public static EmployeeModel ToEmployeeModel(this AcruxMasterData employeedata)
        //{
        //    EmployeeModel dashboardModel = new EmployeeModel();
        //    dashboardModel.EMPID = employeedata.EMP_ID;
        //    dashboardModel.EMPNAME = employeedata.EMP_NAME;
        //    dashboardModel.FATHERNAME = employeedata.FATHER_NAME;
        //    dashboardModel.GENDER = employeedata.GENDER;
        //    dashboardModel.DESIGNATION = employeedata.DESIGNATION;
        //    dashboardModel.DEPARTMENT = employeedata.DEPARTMENT;
        //    dashboardModel.BRANCH = employeedata.BRANCH;
        //    dashboardModel.BLOCK = employeedata.BLOCK;
        //    dashboardModel.DOJ =  employeedata.DOJ;
        //    dashboardModel.CONTACTNO = employeedata.CONTNO;
        //    dashboardModel.EMRCONTACTNO = employeedata.EMERGCONO;
        //    dashboardModel.PERMAILID = employeedata.PMAILID;
        //    dashboardModel.OFFMAILID = employeedata.OFFMAILID;
        //    dashboardModel.DOB = employeedata.DOB; 
        //    dashboardModel.BG = employeedata.BGROUP;
        //    dashboardModel.PRESADDRESS = employeedata.PREADDRESS;
        //    dashboardModel.PERMADDRESS = employeedata.PERADDRESS;
        //    dashboardModel.AADHAR = employeedata.AADHARNO;
        //    dashboardModel.PAN = employeedata.PANCARDNO;
        //    dashboardModel.UAN = employeedata.UANNO;
        //    dashboardModel.ESI = employeedata.ESINO;
        //    dashboardModel.EmpStatu = employeedata.EMPSTAT;
        //    dashboardModel.ResignDate = employeedata.RESIGNDATE;
        //    dashboardModel.ResignType = employeedata.RESIGNTYPE;
        //    dashboardModel.LastWorking = employeedata.LASTWORKDAY;

        //    return dashboardModel;
        //}
        //public static List<EmployeeModel> ToEmployeeModelList(this List<AcruxMasterData> employeeDetailsList)
        //{
        //    List<EmployeeModel> employeeModelList = new List<EmployeeModel>();
        //    foreach (var employee in employeeDetailsList)
        //    {
        //        employeeModelList.Add(employee.ToEmployeeModel());
        //    }

        //    return employeeModelList; 
        //}

        //public static EmployeeLeaveBalanceModel ToEmployeeLeaveBalanceModel(this AcruxLeaveBalance employeeLeaveBalance)
        //{
        //    EmployeeLeaveBalanceModel employeeLeaveBalModel = new EmployeeLeaveBalanceModel();
        //    employeeLeaveBalModel.EmployeeId = employeeLeaveBalance.EmpId;
        //    employeeLeaveBalModel.EmployeeName = employeeLeaveBalance.EmpName;
        //    employeeLeaveBalModel.EmployeeAvlLeaves = employeeLeaveBalance.EmpLeavebalance;
      
        //    return employeeLeaveBalModel;
        //}

    }
}
