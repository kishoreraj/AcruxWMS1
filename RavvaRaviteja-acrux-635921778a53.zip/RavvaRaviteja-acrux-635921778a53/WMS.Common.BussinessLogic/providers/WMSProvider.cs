﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WMS.Common.DataModel;
using WMS.Common.EntityFramework;
using WMS.Common.BussinessLogic;


namespace WMS.Common.BussinessLogic
{
    public class WMSProvider 
        //: IWMSInterface
    {
        WMSEntities datacontext = new WMSEntities();
        public WMSProvider()
        {

        }
        //public EmployeeModel  GetEmployeeDetailsByEmpId(string EmpID)
        //{
        //    EmployeeModel model = new EmployeeModel();
        //    var employeedetails = datacontext.AcruxMasterDatas.Where(a => a.EMP_ID == EmpID).ToList();
        //    if(employeedetails != null && employeedetails.Count > 0)
        //    {
        //        model  =  employeedetails.FirstOrDefault().ToEmployeeModel();
        //    }
        //    return model;
        //}
        //public List<EmployeeModel> GetALLEmployeeDetails()
        //{
        //   List<EmployeeModel> employeeList = new List<EmployeeModel>();
        //    var employeedetails = datacontext.AcruxMasterDatas.ToList();
        //    if (employeedetails != null && employeedetails.Count > 0)
        //    {
        //        employeeList = employeedetails.ToEmployeeModelList();
        //    }
        //    return employeeList;
        //}

        //public EmployeeModel GetUserDetails(string Username, string Password)
        //{
        //    EmployeeModel model = new EmployeeModel();
        //    var employeedetails = datacontext.AcruxMasterDatas.Where(a => a.EMP_ID == Username && a.Password == Password).ToList();
        //    if (employeedetails != null && employeedetails.Count > 0)
        //    {
        //        model = employeedetails.FirstOrDefault().ToEmployeeModel();
        //    }
        //    return model;
        //}


        //public EmployeeSuggestionsModel EmployeeSuggestions(string EmpID)
        //{
        //    EmployeeSuggestionsModel model = new EmployeeSuggestionsModel();
        //    var employeedetails = datacontext.AcruxMasterDatas.Where(a => a.EMP_ID == EmpID).ToList();
        //    if (employeedetails != null && employeedetails.Count > 0)
        //    {
        //       var employee = employeedetails.FirstOrDefault().ToEmployeeModel();
        //        model.EmployeeId = employee.EMPID;
        //        model.EmployeeName = employee.EMPNAME;
        //    }
        //    return model;
        //}
        //public EmployeeSuggestionsModel SaveEmployeeSuggestions(EmployeeSuggestionsModel employeeSuggestionsModel)
        //{
        //    EmployeeSuggestionsModel model = new EmployeeSuggestionsModel();
        //    AcruxSuggestion acruxsuggestions = new AcruxSuggestion();
        //    acruxsuggestions.EmpId = Convert.ToInt32(employeeSuggestionsModel.EmployeeId);
        //    acruxsuggestions.EmpName = employeeSuggestionsModel.EmployeeName;
        //    acruxsuggestions.Date = DateTime.Now.Date;
        //    acruxsuggestions.Suggestion = employeeSuggestionsModel.EmpSuggestions;
        //    datacontext.AcruxSuggestions.Add(acruxsuggestions);
        //    datacontext.SaveChanges();
        //    return model;
        //}
        //public EmployeeLeaveBalanceModel GetLeaveBalance(int EmpId)
        //{
        //    EmployeeLeaveBalanceModel model = new EmployeeLeaveBalanceModel();
            
        //    var employeeleavedetails = datacontext.AcruxLeaveBalances.Where(a => a.EmpId == EmpId).ToList();
        //    if (employeeleavedetails != null && employeeleavedetails.Count > 0)
        //    {
        //        model = employeeleavedetails.FirstOrDefault().ToEmployeeLeaveBalanceModel();
               
        //    }
        //    return model;
        //}

        //public EmployeeLeaveBalanceModel SaveEmployeeLeaveBal(EmployeeLeaveBalanceModel employeeLeaveBalModel)
        //{
        //    EmployeeLeaveBalanceModel model = new EmployeeLeaveBalanceModel();
        //    AcruxLeaveBalance acruxleavebal = new AcruxLeaveBalance();
        //    var employeeleavedetails = datacontext.AcruxLeaveBalances.Where(a => a.EmpId == employeeLeaveBalModel.EmployeeId).ToList();
        //    if (employeeleavedetails != null && employeeleavedetails.Count > 0)
        //    {
        //        acruxleavebal = employeeleavedetails.FirstOrDefault();
        //        acruxleavebal.EmpLeavebalance = acruxleavebal.EmpLeavebalance - employeeLeaveBalModel.EmployeeReqLeaves;

        //    }
        //    datacontext.SaveChanges();
        //    return model;
        //}





    }
}
