﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WMS.Common.DataModel;

namespace WMS.Common.BussinessLogic
{
    public interface IWMSInterface
    {
        EmployeeModel GetEmployeeDetailsByEmpId(string EmpID);

        List<EmployeeModel> GetALLEmployeeDetails();

        EmployeeModel GetUserDetails(string Username, string Password);

        EmployeeSuggestionsModel EmployeeSuggestions(string EmpID);

        EmployeeSuggestionsModel SaveEmployeeSuggestions(EmployeeSuggestionsModel employeeSuggestionsModel);

        EmployeeLeaveBalanceModel GetLeaveBalance(int EmpId);

        EmployeeLeaveBalanceModel SaveEmployeeLeaveBal(EmployeeLeaveBalanceModel employeeLeaveBalModel);
    }
}
