﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WMS.Common.DataModel
{
    public class EmployeeLeaveBalanceModel
    {
        public int EmployeeId { get; set; }

        public string EmployeeName { get; set; }

        public double EmployeeAvlLeaves { get; set; }

        [Required(ErrorMessage = "Please enter Required Leaves")]
        public float EmployeeReqLeaves { get; set; }


    }
}
