﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WMS.Common.DataModel
{
    public class EmployeeModel
    {
        public int SNO { get; set; }
        public string EMPID { get; set; }
        public string EMPNAME { get; set; }
        public string FATHERNAME { get; set; }
        public string GENDER { get; set; }
        public string QUALIFICATION { get; set; }
        public string DESIGNATION { get; set; }
        public string DEPARTMENT { get; set; }
        public string BRANCH { get; set; }
        public string BLOCK { get; set; }
        public DateTime? DOJ { get; set; }
        public int? CONTACTNO { get; set; }
        public int? EMRCONTACTNO { get; set; }
        public string PERMAILID { get; set; }
        public string OFFMAILID { get; set; }
        public DateTime? DOB { get; set; }
        public string BG { get; set; }
        public string PRESADDRESS { get; set; }
        public string PERMADDRESS { get; set; }
        public int? AADHAR { get; set; }
        public string PAN { get; set; }
        public int? UAN { get; set; }
        public int? ESI { get; set; }
        public string EmpStatu { get; set; }
        public DateTime? ResignDate { get; set; }
        public string ResignType { get; set; }
        public DateTime? LastWorking { get; set; }
    }
}
