﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WMS.Common.DataModel
{
    public class EmployeeSuggestionsModel
    {
        public string EmployeeId { get; set; }

        public string EmployeeName { get; set; }

        [Required(ErrorMessage = "Suggestions is required")]
        public string EmpSuggestions { get; set; }

        public DateTime SuggestionDate { get; set; }

        public string Status { get; set; }

    }
}
